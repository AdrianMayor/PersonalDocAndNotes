import { useContext } from "react";
import { CounterContext } from "../../contexts/CounterContext";
import { SwitchContext } from "../../contexts/SwitchContext";
import "./OperationCount.scss";

export function OperationCount() {
  const [, , , , totalCount] = useContext(CounterContext);
  const [theme, changeTheme] = useContext(SwitchContext)

  return (
    <>
    <button onClick={changeTheme}>{theme}</button>
    <p className="operationCount">{`The total operation count is ${totalCount}`}</p>
    </>
  );
}
