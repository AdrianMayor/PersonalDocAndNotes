import { OperationCount } from "../OperationCount/OperationCount";
import { SwitchProvider } from "../../contexts/SwitchContext";
export function Header() {
  return (
    <SwitchProvider>
      <header>
        <h1>useContext Excercises</h1>
        <OperationCount></OperationCount>
      </header>
    </SwitchProvider>
  );
}
