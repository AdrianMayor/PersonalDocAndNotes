import React from 'react'
import { useState } from "react";

export const SwitchContext = React.createContext();

export const SwitchProvider = ({children}) => {
    const [theme, setTheme] = useState('dark')

    const changeTheme = () => {
        if (theme === 'dark') {
            setTheme('ligth')
        } else {
            setTheme('dark')
        }
    }
    return <SwitchContext.Provider value={[theme, changeTheme]}>
        {children}
    </SwitchContext.Provider>
}