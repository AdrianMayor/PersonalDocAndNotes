import { useState, useEffect } from 'react'
import api from '../services'

export const usePrediction = () => {
    const [prediction, setPrediction] = useState(null)
    useEffect(() => {
        const loadData = async () => {
            const myPrediction = await api.weather.getMyWeather()
            setPrediction(myPrediction)
        }
        loadData()
    }, [])

    return prediction
}