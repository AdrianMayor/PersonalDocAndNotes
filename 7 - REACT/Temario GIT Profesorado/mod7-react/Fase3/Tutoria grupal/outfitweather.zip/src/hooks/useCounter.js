import { useState} from 'react'

export const useCounter = ({ initialValue = 0 } = {}) => {
    const [value, setValue] = useState(initialValue < 0 ? 0 : initialValue);

    const increase = () => {
        setValue(value + 1);
    }
    const decrease = () => {
        if (value > 0) {
            setValue(value - 1);
        }
    }
    const reset = () => {
        setValue(0);
    }
    return { value, increase, decrease, reset };
}
export default useCounter;