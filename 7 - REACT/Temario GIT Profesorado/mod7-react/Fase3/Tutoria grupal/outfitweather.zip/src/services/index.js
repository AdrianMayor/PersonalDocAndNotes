import { getLocation, getCity } from '../services/location'
import { getWeather, getMyWeather } from '../services/weather'
import { uploadData } from './upload'
import { getPosts, addPost } from './posts'
import axios from 'axios'
const TOKEN_VALUE = 'token_de_mi_app'

export const getInstance = () => {
    if (localStorage.getItem(TOKEN_VALUE) && !getInstance.__cache) {
        getInstance.__cache = new axios({
            baseURL: process.env.REACT_APP_LOQUIERAS
            headers: {
                'Authorization': localStorage.getItem('token')
            }
        })
    } else if (!localStorage.getItem(TOKEN_VALUE)) {
        getInstance.__cache = undefined
    }
    return getInstance.__cache
}

export const logout = () => {
    localStorage.setItem(TOKEN_VALUE, undefined)
}

export const login = async () => {
    const {data} = await axios.post(/'user', {}, {heade})
    localStorage.setItem(TOKEN_VALUE, data.token)
}


export const getAllData = async () => {
    getInstance().get()
}

const api = {
    location: {
        getLocation,
        getCity
    },
    weather: {
        getWeather,
        getMyWeather
    },
    upload: {
        uploadData
    },
    posts: {
        getPosts,
        addPost
    }
}

export default api