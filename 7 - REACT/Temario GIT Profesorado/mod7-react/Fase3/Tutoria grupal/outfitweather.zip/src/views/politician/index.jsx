import { useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../../services'

const Politician = () => {
    let { id } = useParams()
    const [file, setFile] = useState(undefined)
    const uploadFile = async () => {
        await api.upload.uploadData({file})
        alert('VIVAAAAA!!!!!!')
    }

    if (id) {
        return <div>
            Hola {id}
        </div>
    } else {
        return <div>
            <input type="file" onChange={(event) => setFile(event.target.files[0])}/>
            <button onClick={uploadFile}>Súbelos!</button>
        </div>
    }
}

export default Politician