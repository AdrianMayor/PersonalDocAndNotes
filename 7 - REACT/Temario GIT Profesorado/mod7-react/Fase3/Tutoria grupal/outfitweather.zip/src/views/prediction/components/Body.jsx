import { useState, useEffect } from 'react'
import { usePrediction } from '../../../hooks/prediction'
import { useCounter } from '../../../hooks/useCounter'

const Modificador = ({ onChangeValue }) => {
    const { value, increase, decrease, reset } = useCounter({ initialValue: -1 })

    useEffect(() => {
        onChangeValue(value)
    }, [value, onChangeValue])

    useEffect(() => {
        document.title=`El contador tiene un valor de ${value}`
    }, [value])

    return (
    <>
        <button onClick={increase}>increase</button>
        <button onClick={decrease}>decrease</button>
        <button onClick={reset}>reset</button>
    </>
    )

}

const Body = () => {
    const prediction = usePrediction()
    const [value1, setValue1] = useState(0)
    const [value2, setValue2] = useState(0)
    
    return prediction && <div>
        <h1>{value1} - {value2}</h1>
        <Modificador onChangeValue={setValue1}/>
        <br/>
        <Modificador onChangeValue={setValue2}/>
        <table>
            <thead>
                <tr>
                    <th>Prediction in {prediction.city.name}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{prediction.temperature}</td>
                </tr>
                <tr>
                    <td>{prediction.pop}</td>
                </tr>
                <tr>
                    <td>{prediction.description}</td>
                </tr>
                <tr>
                    <td>{prediction.windGust}</td>
                </tr>
            </tbody>
        </table>
    </div>
}

export default Body