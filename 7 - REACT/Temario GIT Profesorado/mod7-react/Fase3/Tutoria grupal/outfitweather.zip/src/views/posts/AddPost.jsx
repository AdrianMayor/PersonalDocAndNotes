import PropTypes from 'prop-types'
import api from "../../services";

const AddPost = ({ onAddPost }) => {
    const onSubmit = async (event) => {
        event.preventDefault();
        const newPost = {
            title: event.target.elements.title.value,
            body: event.target.elements.body.value,
            userId: event.target.elements.userId.value,
            id: (new Date()).getTime()
        }
        await api.posts.addPost(newPost)
        if (onAddPost) onAddPost(newPost)
        event.target.reset()

    }
    return <form onSubmit={onSubmit}>
        <input name="title" type="text" placeholder="title"/>
        <br/>
        <textarea name="body"></textarea>
        <br/>
        <input type="number" name="userId"/>
        <br/>
        <button>Añadir Post</button>
    </form>
}

AddPost.propTypes = {
    onAddPost: PropTypes.func
}

export default AddPost