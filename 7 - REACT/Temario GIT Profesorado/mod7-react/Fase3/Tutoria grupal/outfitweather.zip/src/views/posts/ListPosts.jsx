import { useEffect } from "react"
import { useState } from "react"
import api from "../../services"
import AddPost from "./AddPost"

const ListPosts = () => {
    const [posts, setPosts] = useState([])
    const [insertData, setInsertData] = useState(false)
    const [isLoading, setIsLoading] = useState(false)

    useEffect(() => {
        const getData = async () => {
            setIsLoading(true)
            const data = await api.posts.getPosts()
            setPosts(data)
            setIsLoading(false)
        }
        getData()
    }, [])

    const addNewPost = (post) => {
        setPosts([post, ...posts])
        setInsertData(false)
    }
    
    return <>
            <button onClick={() => setInsertData(!insertData)}>{insertData ? 'close insert data' : 'show insert data'}</button>
            <hr/>
            {insertData && <AddPost onAddPost={addNewPost}></AddPost>}
            {
                isLoading ? 'Cargando' : 
                <ul>
                    {posts.map(e => <li key={e.id}>{e.title}</li>)}
                </ul>
            }
        </>
}

export default ListPosts