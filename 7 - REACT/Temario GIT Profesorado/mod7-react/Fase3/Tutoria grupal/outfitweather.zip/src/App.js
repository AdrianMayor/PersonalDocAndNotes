import './App.css';
import { Routes, Route, Link } from "react-router-dom";
import Accordion from './components/Accordion';
import Prediction from './views/prediction';
import Politicians from './views/politician';
import ListPosts from './views/posts/ListPosts';
import { useContext } from 'react';


function App() {
  const data = [
    {
      title: "item 1",
      content: "content 1 asd sd sad as dae f dgsd fd ff sdg sdcontent 1 asd sd sad as dae f dgsd fd ff sdg sdcontent 1 asd sd sad as dae f dgsd fd ff sdg sdcontent 1 asd sd sad as dae f dgsd fd ff sdg sdcontent 1 asd sd sad as dae f dgsd fd ff sdg sdcontent 1 asd sd sad as dae f dgsd fd ff sdg sd",
    },
    {
      title: "item 2",
      content: "saf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sf",
    },
    {
      title: "item 3",
      content: "saf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sfsaf dsgmfn sadklgnsdfklgnfsknskfdnhifksngkcontent 2 asfkanfknasfkñnsdakñnakñfnadñfndam,f d,s fds gfdsagsf,ngm fsag fash sf",
    }
  ]
  
  return (
    <div className="App">
      <header>
        <Link to="/politicians">Politicos</Link> | <Link to="/accordion">Acordeones</Link> | <Link to="/">Prediction</Link>
      </header>
      <hr/>
      <Routes>
        <Route path="/" element={<ListPosts />} />
        <Route path="/prediction" element={<Prediction />} />
        <Route path="/accordion" element={<Accordion items={data} openItems={[true, false, true]}></Accordion>} />
        <Route path="/politicians" element={<Politicians/>}/>
        <Route path="/politicians/:id" element={<Politicians/>}/>
      </Routes>  
      <footer>sadasds</footer>
    </div>
  );
}

export default App;
