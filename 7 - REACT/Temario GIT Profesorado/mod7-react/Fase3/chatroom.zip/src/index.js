import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import ChatProvider from './contexts/ChatContext';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
const valorInicial = [
  {
    idUser: 'root',
    message: 'Bienvenido a nuestor chat!',
    hour: new Date().toLocaleString()
  }
]
root.render(
  <React.StrictMode>
    <ChatProvider miValorInicial={valorInicial}>
      <App />
    </ChatProvider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
