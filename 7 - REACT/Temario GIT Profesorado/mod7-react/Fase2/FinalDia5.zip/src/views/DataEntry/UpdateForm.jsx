const { useState } = require("react")

const UpdateForm = ({ email, name, lastname }) => {
    const [myEmail, setMyEmail] = useState(email)
    const [myName, setMyName] = useState(name)
    const [myLastname, setMyLastname] = useState(lastname)

    return <form>
        <input value={myEmail} type="email" onChange={({ target: { value } }) => setMyEmail(value)}/><br/><br/>
        <input value={myName} type="text" onChange={({ target: { value } }) => setMyName(value)}/><br/><br/>
        <input value={myLastname} type="text" onChange={({ target: { value } }) => setMyLastname(value)}/><br/><br/>
        {myEmail} - {myName} - {myLastname} <br/>
        <input type="submit"/>
    </form>
}

export default UpdateForm;