import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';

const DataEntry = () => {
    const [searchText, setSearchText] = useState('SOY FERNANDO')

    const funcionActualizarTexto = ({ target: { value } }) => {
        setSearchText(value)
    }

    return <>
        <InputGroup className='mt-3'>
            <Form.Control
                value={searchText}
                placeholder="Busca aquí"
                onChange={funcionActualizarTexto}
                required
            />
            <Button variant="outline-secondary">
                Añadir
            </Button>
            <Button variant="outline-secondary" onClick={() => setSearchText('')}>
                Clear
            </Button>
        </InputGroup>
    </>
}

export default DataEntry