import { useState } from 'react';
import './App.css';
import DataEntry from './views/DataEntry/Index';
import ButtonColors from './components/ButtonColors';

function App() {
  const [background, setBackground] = useState('white')

  const definicionDeBotones = [
    {
      text: 'Rojo',
      callback: () => setBackground('red')
    },
    {
      text: 'Azul',
      callback: () => setBackground('blue')
    },
    {
      text: 'Verde',
      callback: () => setBackground('green')
    },
    {
      text: 'Amarillo',
      callback: () => setBackground('yellow')
    }
  ]
  
  return (
    <div className="App" style={{minHeight: '100vh', backgroundColor: background}}>
      <ButtonColors elements={definicionDeBotones}>
      </ButtonColors>
      <DataEntry></DataEntry>
    </div>
  );
}

export default App;
