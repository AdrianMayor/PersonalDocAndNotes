import PropTypes from 'prop-types';
const ButtonColors = ({ elements }) => {
    return elements.map((item, index) => <button onClick={item.callback} key={index}>{item.text}</button>)
}

ButtonColors.propTypes = {
    elements: PropTypes.arrayOf(
        PropTypes.shape({
            text: PropTypes.string.isRequired,
            callback: PropTypes.func.isRequired
        })
    )
}

export default ButtonColors;