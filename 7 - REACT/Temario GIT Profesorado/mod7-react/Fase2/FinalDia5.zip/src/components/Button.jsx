const Button = () => {
    return (
        <button>Hola</button>
    )
}
export default Button;