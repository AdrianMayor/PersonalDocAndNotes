import './App.css';
import View2 from './views/View2/Index';

function App() {
  return (
    <div className="App">
      <View2></View2>
    </div>
  );
}

export default App;
