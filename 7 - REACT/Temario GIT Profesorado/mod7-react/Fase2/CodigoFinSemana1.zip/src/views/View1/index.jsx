import Button from "../../components/Button";
import Header from "./components/Header";

const View1 = () => {
    return (
        <div>
            <Header persona='Paula' chorizo='asdasds'>
                <Button></Button>
            </Header>
        </div>
    )
}
export default View1;