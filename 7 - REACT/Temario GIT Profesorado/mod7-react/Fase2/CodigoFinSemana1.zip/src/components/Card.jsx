import Card from 'react-bootstrap/Card';

const MyCard = ({ image, message = 'No tiene mensaje' }) => {
    return (
        <Card style={{ width: '18rem' }}>
            {image && <Card.Img variant="top" src={image} />}
            <Card.Body>
                <Card.Title>Card Title</Card.Title>
                <Card.Text>
                    {message}
                </Card.Text>
            </Card.Body>
        </Card>
    )
}
export default MyCard;

/* Same example with Class component

import Card from 'react-bootstrap/Card';

class MyCard extend React.Component {
    const {image, message} = this.props

    return (
        <Card style={{ width: '18rem' }}>
            {image && <Card.Img variant="top" src={image} />}
            <Card.Body>
                <Card.Title>Card Title</Card.Title>
                <Card.Text>
                    {message}
                </Card.Text>
            </Card.Body>
        </Card>
    )
}

*/