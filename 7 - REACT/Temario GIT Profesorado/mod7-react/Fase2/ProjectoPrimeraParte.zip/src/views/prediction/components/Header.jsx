import './index.scss';
import { useEffect } from 'react';
import { useState } from 'react';
import api from '../../../services';
import IconWeather from '../../../components/IconWeather';
import Location from '../../../components/Location';
import Clock from '../../../components/Clock';

const Header = () => {
    const [prediction, setPrediction] = useState(null)
    useEffect(() => {
        const loadData = async () => {
            const myPrediction = await api.weather.getMyWeather()
            setPrediction(myPrediction)
        }
        loadData()
    }, [])
    
    return prediction && <div className='header'>
        <IconWeather weather={prediction.description} className="icon"></IconWeather>
        <Location city={prediction.city.name} className="location"></Location>
        <Clock className="clock"></Clock>
    </div>
}
export default Header