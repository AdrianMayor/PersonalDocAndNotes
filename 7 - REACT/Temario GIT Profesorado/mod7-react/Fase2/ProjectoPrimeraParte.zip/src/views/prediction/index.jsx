import './index.scss';
import Header from './components/Header'

const Prediction = () => {
    return <div className='prediction'>
        <Header></Header>
    </div>

}

export default Prediction