import './App.css';
import Prediction from './views/prediction';

function App() {
  return (
    <div className="App">
      <Prediction></Prediction>
    </div>
  );
}

export default App;
