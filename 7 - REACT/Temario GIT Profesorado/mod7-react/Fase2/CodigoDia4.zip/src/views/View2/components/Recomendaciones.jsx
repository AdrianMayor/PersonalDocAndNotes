import Card from "../../../components/Card"

const Recomendaciones = () => {
    return <div>
        <Card message="Recomendación 1" image="https://slp-statics.astockcdn.net/static_assets/staging/22spring/homepage/featured-contributors/card-5.jpg?width=580"></Card>
        <Card></Card>
        <Card message="Recomendación 3"></Card>
    </div>
}

export default Recomendaciones