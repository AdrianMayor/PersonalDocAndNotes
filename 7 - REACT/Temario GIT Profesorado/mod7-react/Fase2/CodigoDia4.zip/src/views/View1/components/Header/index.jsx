import './index.css'

const Header = ({ children, persona = 'mundo', chorizo }) => {
    const saludo = `Hola ${persona}!`
    return (
        <header className='header'>
            <div>{saludo}</div>
            <div>{children}</div>
            <div>{chorizo}</div>
        </header>
    )
}
export default Header;