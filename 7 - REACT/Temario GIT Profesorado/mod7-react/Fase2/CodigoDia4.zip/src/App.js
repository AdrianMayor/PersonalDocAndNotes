import { useEffect, useState } from 'react';
import './App.css';
import View3 from './views/View3/Index';
import View4 from './views/View4/Index';

function App() {
  const [altura, setAltura] = useState(11);
  const [nombre] = useState('Hola Que Ase');

  useEffect(() => {
    console.info(altura)
  }, [altura])
  
  return (
    <div className="App">
      <View3
        message='HJOLA A ASDA'
        handleClick={setAltura}
        miCosa={{
          nombre,
          altura
        }}>
      </View3>
      <View4></View4>
    </div>
  );
}

export default App;
