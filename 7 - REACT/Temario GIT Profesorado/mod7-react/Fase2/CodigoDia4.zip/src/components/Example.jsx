import React from 'react';

class Example extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            valor: 0,
            chorizo: 'con patatas'
        };
    }

    async cambiameDeValor () {
        const nuevoValor = this.state.valor + 1;
        await this.setState({
            valor: nuevoValor,
            chorizo: 'example ' + nuevoValor
        })

        console.info(this.state.chorizo)
    }

    render () {
        return <h1 onClick={() => this.cambiameDeValor()}>EXAMPLE: {this.state.valor}</h1>
    }
}

export default Example;