export function Header() {
  return (
    <header>
      <h1>ChatRoom</h1>
    </header>
  );
}
