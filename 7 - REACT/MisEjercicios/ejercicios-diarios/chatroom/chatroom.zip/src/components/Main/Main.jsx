import { ChatBox } from "../ChatBox/ChatBox";
import { ChatRoom } from "../ChatRoom/ChatRoom";

export function Main() {
  return (
    <main>
      {/* <ChatBox></ChatBox> */}
      <ChatRoom></ChatRoom>
    </main>
  );
}
