export function Footer() {
  return <footer>AdrianMayor@</footer>;
}
