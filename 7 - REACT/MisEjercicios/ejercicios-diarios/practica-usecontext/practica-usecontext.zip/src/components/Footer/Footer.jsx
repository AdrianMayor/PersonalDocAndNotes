export function Footer() {
  return (
    <footer>
      <p>AdrianMayor@</p>
    </footer>
  );
}
