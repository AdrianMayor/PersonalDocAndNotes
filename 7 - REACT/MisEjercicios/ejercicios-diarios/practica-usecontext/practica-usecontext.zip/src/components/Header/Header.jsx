import { OperationCount } from "../OperationCount/OperationCount";
export function Header() {
  return (
    <header>
      <h1>useContext Excercises</h1>
      <OperationCount></OperationCount>
    </header>
  );
}
